#include <iostream>
using namespace std;

class Number {
public:
    int value;
    Number(int v = 0) : value(v) {}
    Number operator+(const Number &n) {
        return Number(value + n.value);
    }
};

int main() {
    Number a(10), b(20);
    Number c = a + b;
    cout << c.value << endl;
    return 0;
}
