#include <iostream>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    try {
        if (b == 0) throw "Division by zero";
        cout << (double)a / b << endl;
    }
    catch (const char* message) {
        cout << message << endl;
    }
    return 0;
}
