#include <iostream>
using namespace std;

int main() {
    try {
        throw 10;
    }
    catch (int x) {
        cout << "Integer exception: " << x << endl;
    }
    catch (...) {
        cout << "Other exception" << endl;
    }
    return 0;
}
