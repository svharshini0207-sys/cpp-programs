#include <iostream>
#include <stdexcept>
using namespace std;

int main() {
    int age;
    cin >> age;
    try {
        if (age < 18)
            throw runtime_error("Age must be 18 or above");
        cout << "Eligible" << endl;
    }
    catch (const exception &e) {
        cout << e.what() << endl;
    }
    return 0;
}
