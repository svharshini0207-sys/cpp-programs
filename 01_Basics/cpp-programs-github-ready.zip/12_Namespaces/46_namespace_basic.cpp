#include <iostream>
using namespace std;

namespace First {
    int value = 10;
}

int main() {
    cout << First::value << endl;
    return 0;
}
