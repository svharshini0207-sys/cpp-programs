#include <iostream>
using namespace std;

class Student {
    int marks;
public:
    Student(int m) : marks(m) {}
    void display() { cout << "Marks = " << marks << endl; }
};

int main() {
    Student s(90);
    s.display();
    return 0;
}
