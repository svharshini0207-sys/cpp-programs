# C++ Programs

This repository contains C++ programs developed as part of B.Tech coursework and programming practice.

## Topics Covered

- C++ Basics
- Control Statements
- Functions
- Arrays and Strings
- Pointers
- Classes and Objects
- Constructors and Destructors
- Inheritance
- Polymorphism
- Operator Overloading
- Templates
- Namespaces
- Exception Handling
- File Handling
- Mini Projects

## Mini Projects

- Student Result System
- Calculator
- Number Guessing Game
- Hospital Appointment System
- Shop Billing System

## Language

C++
