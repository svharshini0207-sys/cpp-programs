#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream file("student.txt", ios::app);
    file << "New record added." << endl;
    file.close();
    cout << "Data appended successfully." << endl;
    return 0;
}
