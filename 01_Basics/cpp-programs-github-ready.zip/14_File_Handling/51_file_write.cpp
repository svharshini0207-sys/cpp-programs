#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream file("student.txt");
    file << "Student Result System" << endl;
    file << "C++ File Handling" << endl;
    file.close();
    cout << "Data written successfully." << endl;
    return 0;
}
