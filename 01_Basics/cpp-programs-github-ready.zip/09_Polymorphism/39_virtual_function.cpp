#include <iostream>
using namespace std;

class Parent {
public:
    virtual void show() { cout << "Parent" << endl; }
};

class Child : public Parent {
public:
    void show() override { cout << "Child" << endl; }
};

int main() {
    Parent *p;
    Child c;
    p = &c;
    p->show();
    return 0;
}
