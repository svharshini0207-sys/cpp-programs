#include <iostream>
using namespace std;

class Shape {
public:
    virtual void draw() { cout << "Shape" << endl; }
};

class Circle : public Shape {
public:
    void draw() override { cout << "Circle" << endl; }
};

class Rectangle : public Shape {
public:
    void draw() override { cout << "Rectangle" << endl; }
};

int main() {
    Shape *s;
    Circle c;
    Rectangle r;
    s = &c;
    s->draw();
    s = &r;
    s->draw();
    return 0;
}
