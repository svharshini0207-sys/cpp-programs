#include <iostream>
using namespace std;

int main() {
    int secret = 25, guess;

    cout << "Guess the number: ";
    do {
        cin >> guess;
        if (guess < secret) cout << "Too low. Try again: ";
        else if (guess > secret) cout << "Too high. Try again: ";
    } while (guess != secret);

    cout << "Correct!" << endl;
    return 0;
}
