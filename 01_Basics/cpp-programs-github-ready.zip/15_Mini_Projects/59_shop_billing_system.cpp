#include <iostream>
using namespace std;

int main() {
    string item;
    int quantity;
    double price;

    cout << "Enter item: ";
    cin >> item;
    cout << "Enter quantity: ";
    cin >> quantity;
    cout << "Enter price: ";
    cin >> price;

    double total = quantity * price;

    cout << "\n--- Bill ---" << endl;
    cout << "Item: " << item << endl;
    cout << "Quantity: " << quantity << endl;
    cout << "Price: " << price << endl;
    cout << "Total: " << total << endl;

    return 0;
}
