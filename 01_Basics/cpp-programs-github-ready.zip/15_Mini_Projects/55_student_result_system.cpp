#include <iostream>
using namespace std;

int main() {
    string name;
    int m1, m2, m3;
    cin >> name >> m1 >> m2 >> m3;

    int total = m1 + m2 + m3;
    double percentage = total / 3.0;

    cout << "Student: " << name << endl;
    cout << "Total: " << total << endl;
    cout << "Percentage: " << percentage << "%" << endl;

    if (percentage >= 90) cout << "Grade: A" << endl;
    else if (percentage >= 75) cout << "Grade: B" << endl;
    else if (percentage >= 60) cout << "Grade: C" << endl;
    else cout << "Grade: D" << endl;

    return 0;
}
