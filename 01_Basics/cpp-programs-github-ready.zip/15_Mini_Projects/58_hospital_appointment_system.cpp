#include <iostream>
using namespace std;

int main() {
    string patient, doctor;
    int age;

    cout << "Enter patient name: ";
    cin >> patient;
    cout << "Enter age: ";
    cin >> age;
    cout << "Enter doctor name: ";
    cin >> doctor;

    cout << "\nAppointment Details\n";
    cout << "Patient: " << patient << endl;
    cout << "Age: " << age << endl;
    cout << "Doctor: " << doctor << endl;
    cout << "Appointment booked successfully." << endl;

    return 0;
}
