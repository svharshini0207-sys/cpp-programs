#include <iostream>
using namespace std;

int main() {
    int a[3] = {10, 20, 30};
    int *p = a;
    cout << *p << " " << *(p + 1) << " " << *(p + 2) << endl;
    return 0;
}
