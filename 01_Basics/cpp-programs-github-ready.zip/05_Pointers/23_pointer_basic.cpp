#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;
    int *p = &n;
    cout << "Value = " << *p << endl;
    cout << "Address = " << p << endl;
    return 0;
}
