#include <iostream>
using namespace std;

template <class T>
class Box {
    T value;
public:
    Box(T v) : value(v) {}
    void display() { cout << value << endl; }
};

int main() {
    Box<int> b1(100);
    Box<double> b2(10.5);
    b1.display();
    b2.display();
    return 0;
}
