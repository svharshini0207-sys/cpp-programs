#include <iostream>
using namespace std;

template <class T, class U>
class Pair {
    T first;
    U second;
public:
    Pair(T a, U b) : first(a), second(b) {}
    void display() {
        cout << first << " " << second << endl;
    }
};

int main() {
    Pair<int, string> p(1, "C++");
    p.display();
    return 0;
}
