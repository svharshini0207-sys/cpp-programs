#include <iostream>
using namespace std;

class Employee {
public:
    string name;
    double salary;
    void display() {
        cout << "Name: " << name << endl;
        cout << "Salary: " << salary << endl;
    }
};

int main() {
    Employee e;
    cin >> e.name >> e.salary;
    e.display();
    return 0;
}
