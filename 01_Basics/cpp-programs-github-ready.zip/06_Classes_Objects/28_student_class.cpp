#include <iostream>
using namespace std;

class Student {
    int marks;
public:
    void setMarks(int m) { marks = m; }
    void display() { cout << "Marks = " << marks << endl; }
};

int main() {
    Student s;
    int m;
    cin >> m;
    s.setMarks(m);
    s.display();
    return 0;
}
