#include <iostream>
using namespace std;

int main() {
    int n, original, reverse = 0;
    cin >> n;
    original = n;
    while (n > 0) {
        reverse = reverse * 10 + n % 10;
        n /= 10;
    }
    cout << (original == reverse ? "Palindrome" : "Not Palindrome") << endl;
    return 0;
}
