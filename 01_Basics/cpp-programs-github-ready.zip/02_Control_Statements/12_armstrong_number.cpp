#include <iostream>
using namespace std;

int main() {
    int n, original, sum = 0;
    cin >> n;
    original = n;
    while (n > 0) {
        int d = n % 10;
        sum += d * d * d;
        n /= 10;
    }
    cout << (sum == original ? "Armstrong Number" : "Not Armstrong Number") << endl;
    return 0;
}
