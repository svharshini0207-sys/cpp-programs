#include <iostream>
using namespace std;

int main() {
    int n, sum = 0;
    cin >> n;
    int a[100];
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        sum += a[i];
    }
    cout << "Sum = " << sum << endl;
    cout << "Average = " << (double)sum / n << endl;
    return 0;
}
