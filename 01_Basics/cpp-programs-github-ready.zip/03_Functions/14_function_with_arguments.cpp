#include <iostream>
using namespace std;

int add(int a, int b) {
    return a + b;
}

int main() {
    int a, b;
    cin >> a >> b;
    cout << "Sum = " << add(a, b) << endl;
    return 0;
}
